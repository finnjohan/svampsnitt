# Svampsnitt

A slicing game for Ubuntu Touch. Mushrooms fly up from the moss – swipe across them to slice them in two. But never slice the fly agaric!

- Three modes: **Classic** (three lives, a fly agaric ends the game), **Against the clock** (60 seconds, a fly agaric costs 10 points) and **Zen** (90 seconds, no fly agarics)
- Chanterelles, porcini, funnel chanterelles, birch boletes and puffballs
- Combos: slice three or more in one swipe for bonus points
- Summer, autumn and winter forest (automatic from the calendar or chosen in settings)
- Light, dark (evening) or automatic theme
- English and Swedish
- Records and top games saved locally (SQLite)
- Pure QML, no extra libraries. All graphics and sounds are made for this game

## Svenska

Ett spel för Ubuntu Touch där svampar flyger upp ur mossan och du klyver dem med ett svep. Men klyv aldrig flugsvampen! Tre lägen: klassiskt med tre liv, på tid (60 sekunder) och zen (90 sekunder utan flugsvampar).

## Build

```bash
clickable build
# or without clickable:
click build <dir with qml/, assets/, manifest.json, svampsnitt.apparmor, svampsnitt.desktop, LICENSE>
```

## Development

```bash
node tests/logic.test.js      # rules + a computer player plays 40 games in each mode
node tests/i18n.test.js       # every text has a Swedish translation
python3 tools/make_art.py     # regenerates the SVG graphics
python3 tools/make_sounds.py  # regenerates the sound effects (numpy, scipy)
GRID_UNIT_PX=16 UITK_ICON_THEME=suru qmlscene qml/Main.qml --page=game --autoplay
```

Test flags: `--demo`, `--autoplay`, `--seed=<n>`, `--mode=classic|timed|zen`, `--lang=sv|en`, `--theme=light|dark`, `--season=summer|autumn|winter`, `--page=game|settings|records`, `--mute`.

The background sounds come from [Kottslungan](https://github.com/finnjohan/kottslungan) by the same author.

## License

GPL-3.0-or-later © 2026 Johan Finn
