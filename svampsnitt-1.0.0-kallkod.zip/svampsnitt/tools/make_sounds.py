#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Johan Finn
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Skapar spelets ljudeffekter från grunden med numpy (inga inspelningar, inga
# lånade ljud). Kör: python3 tools/make_sounds.py   (kräver numpy och scipy)
# Bakgrundsljuden (ambience-*.ogg) kommer från Kottslungan, samma upphovsperson.
import os
import wave

import numpy as np
from scipy.signal import butter, sosfilt

SR = 22050
OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "sounds")
rng = np.random.default_rng(2026)


def t_of(sec):
    return np.arange(int(sec * SR)) / SR


def band(x, lo, hi):
    return sosfilt(butter(2, [lo, hi], "band", fs=SR, output="sos"), x)


def low(x, f):
    return sosfilt(butter(2, f, "low", fs=SR, output="sos"), x)


def place(buf, clip, at):
    i = int(at * SR)
    n = min(len(clip), len(buf) - i)
    buf[i:i + n] += clip[:n]


def bell(freqs, step, sec, decay=7):
    out = np.zeros(int(sec * SR))
    for i, f in enumerate(freqs):
        tt = t_of(0.6)
        note = (np.sin(2 * np.pi * f * tt) + 0.3 * np.sin(2 * np.pi * 2 * f * tt) * np.exp(-tt * 12)) * np.exp(-tt * decay)
        place(out, note * 0.6, i * step)
    return out


def swish(sec, f0, f1):
    """Brus vars band sveper från f0 till f1: ett snabbt svep genom luften."""
    t = t_of(sec)
    n = rng.normal(size=len(t))
    out = np.zeros(len(t))
    parts = 12
    edges = np.linspace(0, len(t), parts + 1).astype(int)
    for k in range(parts):
        f = f0 * (f1 / f0) ** (k / (parts - 1))
        seg = band(n, f * 0.6, min(f * 1.6, SR / 2 - 100))
        out[edges[k]:edges[k + 1]] = seg[edges[k]:edges[k + 1]]
    return out * np.sin(np.pi * t / sec) ** 2


def sfx_launch():        # svampen skjuts upp ur mossan
    t = t_of(0.3)
    pop = np.sin(2 * np.pi * np.cumsum(np.geomspace(140, 320, len(t))) / SR) * np.exp(-t * 18)
    return 0.6 * swish(0.3, 400, 1600) + 0.5 * pop


def sfx_slice(pitch=1.0):  # svisch + saftigt snitt
    t = t_of(0.32)
    out = 0.8 * swish(0.18, 2500 * pitch, 6000 * pitch)
    out = np.concatenate([out, np.zeros(len(t) - len(out))])
    wet = band(rng.normal(size=len(t)), 300 * pitch, 1400 * pitch) * np.exp(-t * 22)
    thock = np.sin(2 * np.pi * 180 * pitch * t * (1 - 0.6 * t)) * np.exp(-t * 30)
    place(out, 0.7 * wet + 0.6 * thock, 0.04)
    return out


def sfx_combo():
    return bell([659.25, 783.99, 987.77, 1318.5], 0.07, 0.9, decay=6)


def sfx_bomb():          # flugsvampen pyser: låg duns och en sporsky
    t = t_of(1.0)
    boom = low(rng.normal(size=len(t)), 500) * np.exp(-t * 7)
    hiss = band(rng.normal(size=len(t)), 2000, 7000) * np.exp(-t * 3) * 0.35
    thud = np.sin(2 * np.pi * 70 * t * (1 - 0.3 * t)) * np.exp(-t * 8)
    return 0.9 * boom + hiss + 0.8 * thud


def sfx_miss():          # svampen dunsar ner i mossan
    t = t_of(0.35)
    return (np.sin(2 * np.pi * 110 * t * (1 - 0.5 * t)) * np.exp(-t * 20)
            + 0.4 * low(rng.normal(size=len(t)), 900) * np.exp(-t * 25))


def sfx_tick():          # träklick de sista sekunderna
    t = t_of(0.12)
    return np.sin(2 * np.pi * 1200 * t) * np.exp(-t * 70) + 0.3 * band(rng.normal(size=len(t)), 2000, 5000) * np.exp(-t * 90)


def sfx_start():
    return bell([523.25, 659.25, 783.99, 1046.5], 0.06, 0.8, decay=6)


def sfx_over():
    return bell([783.99, 659.25, 523.25, 392.0], 0.14, 1.2, decay=5)


def normalize(y, peak):
    return y / np.max(np.abs(y)) * peak


def write_wav(path, y):
    y = np.clip(y, -1, 1)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((y * 32767).astype(np.int16).tobytes())


def main():
    os.makedirs(OUT, exist_ok=True)
    effects = {
        "launch": (sfx_launch, 0.35), "slice1": (lambda: sfx_slice(1.0), 0.7),
        "slice2": (lambda: sfx_slice(1.15), 0.7), "slice3": (lambda: sfx_slice(0.88), 0.7),
        "combo": (sfx_combo, 0.6), "bomb": (sfx_bomb, 0.85), "miss": (sfx_miss, 0.6),
        "tick": (sfx_tick, 0.5), "start": (sfx_start, 0.55), "over": (sfx_over, 0.6),
    }
    for name, (fn, peak) in effects.items():
        y = normalize(fn(), peak)
        fade = min(len(y), int(0.01 * SR))
        y[-fade:] *= np.linspace(1, 0, fade)
        write_wav(os.path.join(OUT, name + ".wav"), y)
        print(name, f"{len(y) / SR:.2f} s")


if __name__ == "__main__":
    main()
