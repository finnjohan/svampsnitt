#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Johan Finn
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Ritar spelets grafik som SVG. All grafik är gjord för Svampsnitt.
# Kör: python3 tools/make_art.py   (skriver till assets/)
import math
import os
import random

OUT = os.path.join(os.path.dirname(__file__), "..", "assets")


def svg(w, h, body, defs=""):
    d = f"<defs>{defs}</defs>" if defs else ""
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">\n'
            f"{d}{body}\n</svg>\n")


def write(name, content):
    with open(os.path.join(OUT, name), "w") as f:
        f.write(content)


def inner(s):
    """Innehållet i en svg-sträng, utan <svg>-taggen (för att bädda in i loggan)."""
    return s[s.index(">") + 1:s.rindex("</svg>")]


# ---- Svamparna, 128 × 128, centrerade så att de fyller en cirkel ------------
def chanterelle():
    return svg(128, 128, """
<path d="M52,118 Q50,92 38,70 L90,70 Q78,92 76,118 Q64,124 52,118 Z" fill="#E9A52A"/>
<path d="M44,72 L58,112 M56,72 L62,116 M70,72 L66,116 M82,72 L70,112" stroke="#C9821A" stroke-width="3" stroke-linecap="round"/>
<path d="M8,52 Q10,30 30,26 Q48,16 64,22 Q82,16 98,26 Q120,30 120,52 Q112,58 104,56 Q96,66 84,62 Q74,72 64,66 Q54,72 44,62 Q32,66 24,56 Q14,58 8,52 Z" fill="#F4B830"/>
<path d="M22,40 Q40,28 62,30" stroke="#FFE08A" stroke-width="6" stroke-linecap="round" fill="none"/>
<path d="M24,56 Q44,60 64,66 Q84,60 104,56" stroke="#D99520" stroke-width="3" fill="none" stroke-linecap="round"/>
""")


def porcini():
    return svg(128, 128, """
<path d="M40,124 Q30,96 40,66 L88,66 Q98,96 88,124 Q64,128 40,124 Z" fill="#EFE3C4"/>
<path d="M46,80 L52,86 L46,92 M56,84 L62,90 L56,96 M70,82 L76,88 L70,94 M80,92 L84,98 M48,104 L54,110 M66,104 L72,110" stroke="#CDBB92" stroke-width="2" fill="none" stroke-linecap="round"/>
<path d="M6,62 Q4,22 64,10 Q124,22 122,62 Q100,74 64,72 Q28,74 6,62 Z" fill="#8A4F25"/>
<path d="M8,62 Q30,72 64,70 Q98,72 120,62 Q112,70 64,74 Q16,70 8,62 Z" fill="#E8D7A6"/>
<path d="M26,34 Q42,18 66,18" stroke="#B0703A" stroke-width="8" stroke-linecap="round" fill="none"/>
""")


def trumpet():
    return svg(128, 128, """
<path d="M54,122 Q52,96 46,74 L82,74 Q76,96 74,122 Q64,126 54,122 Z" fill="#E7B53C"/>
<path d="M58,80 L60,116 M70,80 L68,116" stroke="#C8962A" stroke-width="2.5" stroke-linecap="round"/>
<path d="M14,34 Q30,42 44,44 Q54,62 64,80 Q74,62 84,44 Q98,42 114,34 Q110,58 92,68 Q78,78 64,80 Q50,78 36,68 Q18,58 14,34 Z" fill="#5D4A3E"/>
<path d="M14,34 Q30,22 64,24 Q98,22 114,34 Q100,46 64,44 Q28,46 14,34 Z" fill="#3B2E27"/>
<path d="M30,52 Q44,64 58,72" stroke="#7A6656" stroke-width="3" fill="none" stroke-linecap="round"/>
""")


def birch():
    return svg(128, 128, """
<path d="M50,124 Q46,92 52,60 L76,60 Q82,92 78,124 Q64,128 50,124 Z" fill="#F1ECE2"/>
<path d="M54,70 L56,74 M70,72 L72,76 M58,86 L60,90 M68,92 L66,96 M56,102 L58,106 M72,108 L70,112 M62,78 L64,82 M64,116 L66,120" stroke="#3E342C" stroke-width="3.5" stroke-linecap="round"/>
<path d="M12,60 Q10,22 64,16 Q118,22 116,60 Q94,70 64,68 Q34,70 12,60 Z" fill="#9C6B3E"/>
<path d="M14,60 Q36,68 64,66 Q92,68 114,60 Q104,70 64,72 Q24,70 14,60 Z" fill="#EDE2CB"/>
<path d="M30,36 Q44,24 64,24" stroke="#BD8C58" stroke-width="7" stroke-linecap="round" fill="none"/>
""")


def puffball():
    random.seed(7)
    warts = "".join(
        f'<circle cx="{40 + random.random() * 48:.1f}" cy="{26 + random.random() * 52:.1f}" r="{2 + random.random() * 2.5:.1f}" fill="#E4DDCB"/>'
        for _ in range(26))
    return svg(128, 128, f"""
<path d="M46,96 Q46,118 64,122 Q82,118 82,96 Z" fill="#E8E0CC"/>
<path d="M20,64 Q20,16 64,14 Q108,16 108,64 Q108,100 64,104 Q20,100 20,64 Z" fill="#FAF6EC"/>
<path d="M26,72 Q30,96 64,100 Q98,96 102,72 Q96,98 64,104 Q32,98 26,72 Z" fill="#E0D7C1"/>
{warts}
<path d="M36,38 Q46,24 62,24" stroke="#FFFFFF" stroke-width="7" stroke-linecap="round" fill="none"/>
""")


def flyagaric():
    dots = [(36, 34, 6), (58, 22, 7), (82, 28, 6), (100, 46, 5), (24, 52, 5), (48, 46, 5), (72, 44, 6), (90, 58, 4), (40, 60, 3.5)]
    spots = "".join(f'<circle cx="{x}" cy="{y}" r="{r}" fill="#FFFFFF"/>' for x, y, r in dots)
    return svg(128, 128, f"""
<path d="M50,124 Q46,96 52,64 L76,64 Q82,96 78,124 Q64,128 50,124 Z" fill="#FBF8F0"/>
<path d="M44,84 Q64,96 84,84 L86,92 Q64,104 42,92 Z" fill="#F2EBDC"/>
<path d="M44,122 Q64,114 84,122 Q82,128 64,128 Q46,128 44,122 Z" fill="#F2EBDC"/>
<path d="M8,66 Q6,18 64,10 Q122,18 120,66 Q96,76 64,74 Q32,76 8,66 Z" fill="#D62B1F"/>
<path d="M10,66 Q32,74 64,72 Q96,74 118,66 Q108,76 64,78 Q20,76 10,66 Z" fill="#F7F2E4"/>
<path d="M22,40 Q30,24 46,18" stroke="#EE5A48" stroke-width="7" stroke-linecap="round" fill="none"/>
{spots}
""")


SHROOMS = {
    "chanterelle": chanterelle, "porcini": porcini, "trumpet": trumpet,
    "birch": birch, "puffball": puffball, "flyagaric": flyagaric,
}


# ---- Bakgrund: skogsbryn med mossa, per årstid, 720 × 1280 --------------------
def background(season):
    random.seed(2026)
    pal = {
        "summer": dict(sky1="#86C7EE", sky2="#E3F3FA", far="#7FA68A", trees="#2E5A36", trees2="#3C6E42",
                       ground="#4F8A3C", moss="#6AA84A", moss2="#7DBB55", trunk="#5A3D26"),
        "autumn": dict(sky1="#9DB8CF", sky2="#F1E6CF", far="#A69A72", trees="#3B5730", trees2="#C98A2E",
                       ground="#6E7A34", moss="#8A9440", moss2="#B08A3A", trunk="#5A3D26"),
        "winter": dict(sky1="#A9C9E2", sky2="#F0F5FA", far="#B8C8D4", trees="#2F4A3E", trees2="#3E5C4C",
                       ground="#E8EEF3", moss="#F4F8FB", moss2="#DCE6EE", trunk="#4A3A30"),
    }[season]
    p = []
    p.append(f'<rect width="720" height="1280" fill="url(#sky)"/>')
    # Avlägsna åsar
    p.append(f'<path d="M0,620 Q120,560 240,600 Q380,540 520,590 Q620,560 720,580 L720,1280 L0,1280 Z" fill="{pal["far"]}" opacity="0.7"/>')
    # Granar i fjärran
    x = -20
    while x < 740:
        h = 120 + random.random() * 140
        w = 40 + random.random() * 26
        base = 760 + random.random() * 30
        p.append(f'<path d="M{x:.0f},{base:.0f} L{x + w / 2:.0f},{base - h:.0f} L{x + w:.0f},{base:.0f} Z" fill="{pal["trees"]}" opacity="0.75"/>')
        x += w * 0.6
    # Stammar och träd närmare
    for i in range(7):
        tx = 30 + i * 110 + random.random() * 40
        if season == "winter" or random.random() < 0.6:
            # gran
            h = 420 + random.random() * 160
            tiers = ""
            for k in range(7):
                ty = 900 - h + k * h / 8
                tw = 30 + k * 16
                tiers += f'<path d="M{tx:.0f},{ty - 40:.0f} L{tx + tw:.0f},{ty + 40:.0f} L{tx - tw:.0f},{ty + 40:.0f} Z" fill="{pal["trees"]}"/>'
                if season == "winter":
                    tiers += f'<path d="M{tx:.0f},{ty - 40:.0f} L{tx + tw * 0.35:.0f},{ty - 18:.0f} Q{tx:.0f},{ty - 12:.0f} {tx - tw * 0.35:.0f},{ty - 18:.0f} Z" fill="#F4F8FB"/>'
            p.append(f'<rect x="{tx - 7:.0f}" y="{900 - 140:.0f}" width="14" height="160" fill="{pal["trunk"]}"/>' + tiers)
        else:
            # björk
            p.append(f'<path d="M{tx - 8:.0f},940 L{tx - 5:.0f},420 L{tx + 5:.0f},420 L{tx + 9:.0f},940 Z" fill="#EFEBE2"/>')
            for k in range(6):
                yy = 470 + k * 80 + random.random() * 30
                p.append(f'<path d="M{tx - 6:.0f},{yy:.0f} L{tx + 2:.0f},{yy - 3:.0f}" stroke="#2B2B2B" stroke-width="4" stroke-linecap="round"/>')
            p.append(f'<ellipse cx="{tx:.0f}" cy="430" rx="90" ry="110" fill="{pal["trees2"]}" opacity="0.95"/>')
    # Marken och mossan
    p.append(f'<path d="M0,900 Q180,870 360,890 Q540,910 720,880 L720,1280 L0,1280 Z" fill="{pal["ground"]}"/>')
    for i in range(40):
        cx = random.random() * 720
        cy = 930 + random.random() * 330
        rx = 40 + random.random() * 70
        p.append(f'<ellipse cx="{cx:.0f}" cy="{cy:.0f}" rx="{rx:.0f}" ry="{rx * 0.35:.0f}" fill="{random.choice([pal["moss"], pal["moss2"]])}" opacity="0.8"/>')
    # Stenar
    for cx, cy, s in [(110, 1040, 1.0), (600, 1130, 1.3), (420, 980, 0.7)]:
        top = "#F4F8FB" if season == "winter" else "#9A9A94"
        p.append(f'<path d="M{cx - 60 * s:.0f},{cy:.0f} Q{cx - 50 * s:.0f},{cy - 50 * s:.0f} {cx:.0f},{cy - 56 * s:.0f} '
                 f'Q{cx + 54 * s:.0f},{cy - 46 * s:.0f} {cx + 62 * s:.0f},{cy:.0f} Z" fill="#8A8A86"/>'
                 f'<path d="M{cx - 40 * s:.0f},{cy - 34 * s:.0f} Q{cx:.0f},{cy - 60 * s:.0f} {cx + 40 * s:.0f},{cy - 36 * s:.0f}" '
                 f'stroke="{top}" stroke-width="{10 * s:.0f}" fill="none" stroke-linecap="round"/>')
    # Lingonris och blåbärsris (inte på vintern)
    if season != "winter":
        for i in range(16):
            cx = random.random() * 720
            cy = 960 + random.random() * 300
            leaf = "#2F6B2E" if season == "summer" else "#7A5A2A"
            p.append(f'<ellipse cx="{cx:.0f}" cy="{cy:.0f}" rx="16" ry="8" fill="{leaf}"/>'
                     f'<ellipse cx="{cx + 14:.0f}" cy="{cy - 6:.0f}" rx="14" ry="7" fill="{leaf}"/>')
            if random.random() < 0.6:
                p.append(f'<circle cx="{cx + 6:.0f}" cy="{cy + 4:.0f}" r="6" fill="#C8102E"/><circle cx="{cx + 16:.0f}" cy="{cy + 6:.0f}" r="5" fill="#B50E28"/>')
    else:
        for i in range(60):
            p.append(f'<circle cx="{random.random() * 720:.0f}" cy="{random.random() * 900:.0f}" r="{1.5 + random.random() * 2.5:.1f}" fill="#FFFFFF" opacity="0.8"/>')
    defs = (f'<linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">'
            f'<stop offset="0" stop-color="{pal["sky1"]}"/><stop offset="0.55" stop-color="{pal["sky2"]}"/></linearGradient>')
    return svg(720, 1280, "\n".join(p), defs)


# ---- Ikon ---------------------------------------------------------------------
def logo():
    c = inner(chanterelle())
    return svg(256, 256, f"""
<defs>
  <clipPath id="r"><rect width="256" height="256" rx="48"/></clipPath>
  <clipPath id="top"><path d="M-40,-40 L300,-40 L300,90 L-40,170 Z"/></clipPath>
  <clipPath id="bot"><path d="M-40,170 L300,90 L300,300 L-40,300 Z"/></clipPath>
</defs>
<g clip-path="url(#r)">
<rect width="256" height="256" fill="#3E7A3E"/>
<ellipse cx="128" cy="236" rx="170" ry="54" fill="#5E9E48"/>
<g clip-path="url(#top)"><g transform="translate(-14,-24) rotate(-8 128 128)"><g transform="translate(24,24) scale(1.62)">{c}</g></g></g>
<g clip-path="url(#bot)"><g transform="translate(10,14) rotate(6 128 128)"><g transform="translate(24,24) scale(1.62)">{c}</g></g></g>
<path d="M18,186 Q120,140 240,64" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" fill="none" opacity="0.95"/>
<path d="M30,180 Q120,142 228,74" stroke="#FFF4C2" stroke-width="4" stroke-linecap="round" fill="none"/>
</g>
""")


def main():
    os.makedirs(OUT, exist_ok=True)
    for name, fn in SHROOMS.items():
        write(f"{name}.svg", fn())
    for season in ("summer", "autumn", "winter"):
        write(f"bg-{season}.svg", background(season))
    write("logo.svg", logo())


if __name__ == "__main__":
    main()
