// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
// Kör: node tests/logic.test.js [antal frön] [sekunder]
// Reglerna testas var för sig, och sedan spelar datorspelaren många omgångar
// i varje läge. Alla svampar ska gå att nå och klassiskt läge ska gå att klara.
const L = require("./load.js")(["Logic.js"])
let fail = 0
function check(ok, msg) { if (!ok) { fail++; console.log("FEL:", msg) } }
const DT = 1 / 60
const H = 10 * 16 / 9

function quiet(mode) { const s = L.newGame(mode, 1, H); s.spawnT = 1e9; return s }
function run(s, sec, act) { for (let i = 0; i < sec / DT && !s.over; i++) { if (act) act(s, i); L.step(s, DT) } return s }

// ---- Enskilda regler -------------------------------------------------------------
{   // Kastbanan: toppen där vi bad om den, och den landar där vi sa
    const s = quiet("zen")
    const it = L.launch(s, "porcini", 2, 7, 0.7)
    let top = -1e9
    run(s, 4, () => { if (s.items.length) top = Math.max(top, s.items[0].y) })
    check(Math.abs(top - 0.7 * H) < 0.15, "toppen ska vara 0,7 H (" + top.toFixed(2) + ")")
    check(s.items.length === 0 && s.misses === 1, "svampen ska falla ut och räknas som miss")
}
{   // Ett snitt genom en svamp: två halvor, poäng, saft
    const s = quiet("classic")
    const it = L.launch(s, "chanterelle", 5, 5, 0.7)
    run(s, 0.8)
    const n = L.slice(s, it.x - 2, it.y, it.x + 2, it.y, 0.05)
    check(n === 1 && s.score === 1 && s.pieces.length === 2 && s.drops.length > 0, "snitt ger poäng, halvor och saft")
    check(s.items.length === 0, "kluven svamp tas bort")
    run(s, 4)
    check(s.lives === 3 && s.misses === 0, "kluven svamp räknas inte som miss")
    check(s.pieces.length === 0, "halvorna faller ut")
}
{   // Långsamt drag klyver inte
    const s = quiet("classic")
    const it = L.launch(s, "chanterelle", 5, 5, 0.7)
    run(s, 0.8)
    check(L.slice(s, it.x - 2, it.y, it.x + 2, it.y, 2) === 0, "långsamt drag ska inte klyva")
}
{   // Miss kostar liv i klassiskt läge, tre missar är slut
    const s = quiet("classic")
    for (let i = 0; i < 3; i++) L.launch(s, "trumpet", 2 + i * 3, 2 + i * 3, 0.6)
    run(s, 4)
    check(s.over && s.reason === "lives" && s.lives === 0, "tre missar ska avsluta klassiskt läge")
    const z = quiet("zen"); L.launch(z, "trumpet", 5, 5, 0.6); run(z, 4)
    check(!z.over && z.misses === 1, "miss i zen kostar inget")
}
{   // Flugsvamp som faller ut är ingen miss
    const s = quiet("classic"); L.launch(s, "flyagaric", 5, 5, 0.6); run(s, 4)
    check(s.lives === 3 && s.misses === 0, "flugsvamp som faller ska inte kosta liv")
}
{   // Flugsvamp: slut i klassiskt, minuspoäng på tid
    const s = quiet("classic"); const b = L.launch(s, "flyagaric", 5, 5, 0.6); run(s, 0.6)
    L.slice(s, b.x - 2, b.y, b.x + 2, b.y, 0.05)
    check(s.over && s.reason === "bomb", "flugsvamp ska avsluta klassiskt läge")
    const t = quiet("timed"); t.score = 15; const c = L.launch(t, "flyagaric", 5, 5, 0.6); run(t, 0.6)
    L.slice(t, c.x - 2, c.y, c.x + 2, c.y, 0.05)
    check(!t.over && t.score === 5, "flugsvamp på tid ger −10 (" + t.score + ")")
}
{   // Kombo: tre i samma svep ger tre extra poäng
    const s = quiet("timed")
    const a = [2, 5, 8].map(x => L.launch(s, "chanterelle", x, x, 0.7))
    run(s, 0.8)
    L.slice(s, 0.5, a[0].y, 9.5, a[0].y, 0.08)
    run(s, 0.5)
    check(s.score === 6 && s.bestCombo === 3, "kombo om tre ger 3 + 3 poäng (" + s.score + ")")
}
{   // Tiden tar slut
    const s = L.newGame("timed", 3, H); run(s, 61)
    check(s.over && s.reason === "time" && s.timeLeft === 0, "tidsläget slutar efter 60 s")
    const z = L.newGame("zen", 3, H); run(z, 89)
    check(!z.over, "zen pågår i 90 s"); run(z, 2); check(z.over, "zen slutar efter 90 s")
    check(!z.events.some(e => e.type === "launch" && e.bomb), "zen ska inte ha flugsvampar")
}
{   // Samma frö, samma spel
    const a = run(L.newGame("classic", 42, H), 20), b = run(L.newGame("classic", 42, H), 20)
    check(JSON.stringify(a.items) === JSON.stringify(b.items), "samma frö ska ge samma svampar")
}

// ---- Alla kast håller sig på skärmen ------------------------------------------
for (const h of [H, 10 * 2.2, 10 * 1.5]) {
    let bad = 0, count = 0
    for (let seed = 1; seed <= 10; seed++) {
        const s = L.newGame("timed", seed, h)
        for (let i = 0; i < 60 / DT && !s.over; i++) {
            L.step(s, DT)
            for (const it of s.items) {
                if (it.x < it.r * 0.9 || it.x > L.W - it.r * 0.9 || it.y > h - it.r * 0.9) { bad++; it.sliced = true }
            }
            count += s.events.filter(e => e.type === "launch").length
            s.events = []
        }
    }
    check(bad === 0, `svampar utanför skärmen vid höjd ${h.toFixed(1)}: ${bad} av ${count}`)
}

// ---- Datorspelaren ------------------------------------------------------------------
const seeds = parseInt(process.argv[2] || "40", 10)
const secs = parseInt(process.argv[3] || "240", 10)
for (const mode of ["classic", "timed", "zen"]) {
    let ends = {}, scores = [], misses = 0, bombs = 0, combos = 0, maxItems = 0
    for (let seed = 1; seed <= seeds; seed++) {
        const s = L.newGame(mode, seed, H)
        for (let i = 0; i < secs / DT && !s.over; i++) {
            const seg = L.bot(s)
            if (seg) L.slice(s, seg[0], seg[1], seg[2], seg[3], DT)
            L.step(s, DT)
            maxItems = Math.max(maxItems, s.items.length)
            combos += s.events.filter(e => e.type === "combo").length
            s.events = []
        }
        ends[s.reason || "ingen"] = (ends[s.reason || "ingen"] || 0) + 1
        scores.push(s.score); misses += s.misses; bombs += s.bombs
    }
    const avg = scores.reduce((a, b) => a + b, 0) / scores.length
    console.log(`${mode}: snitt ${avg.toFixed(0)} poäng (min ${Math.min(...scores)}, max ${Math.max(...scores)}), ` +
                `missar ${misses}, flugsvampar ${bombs}, kombor ${combos}, högst ${maxItems} i luften, slut: ${JSON.stringify(ends)}`)
    check(bombs === 0, `${mode}: datorspelaren klöv ${bombs} flugsvampar`)
    if (mode === "classic") check(misses <= Math.ceil(seeds * 0.1), `classic: för många missar (${misses})`)
}
console.log(fail ? `${fail} fel` : "alla tester gick igenom")
process.exit(fail ? 1 : 0)
