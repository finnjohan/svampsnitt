.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
//
// Spelreglerna för Svampsnitt, utan QML-beroenden (testas med node).
// Världen är W = 10 enheter bred och H = W × höjd/bredd hög. y växer uppåt,
// marken är y = 0. Svamparna kastas upp underifrån och faller tillbaka.
// Vinklar (rot, cut) är i skärmens grader, eftersom de bara används för att rita.

var W = 10
var COMBO_WINDOW = 0.22     // träffar så här tätt räknas som samma svep
var MIN_SPEED = 7           // ett svep måste gå minst så här fort (enheter/s)
var BOMB_PENALTY = 10       // flugsvamp på tid: minuspoäng
var MAX_DROPS = 90
var MAX_PIECES = 40

var MODES = {
    classic: { lives: 3, time: 0,  bombs: true },
    timed:   { lives: 0, time: 60, bombs: true },
    zen:     { lives: 0, time: 90, bombs: false }
}

// r = radie i världsenheter. bomb = flugsvamp.
var KINDS = {
    chanterelle: { r: 0.72 },
    porcini:     { r: 0.86 },
    trumpet:     { r: 0.62 },
    birch:       { r: 0.78 },
    puffball:    { r: 0.68 },
    flyagaric:   { r: 0.80, bomb: true }
}
var SHROOMS = ["chanterelle", "porcini", "trumpet", "birch", "puffball"]

// ---- Slump med frö (mulberry32) ---------------------------------------------
function makeRand(seed) {
    var a = (seed >>> 0) || 1
    return function () {
        a = (a + 0x6D2B79F5) >>> 0
        var t = a
        t = Math.imul(t ^ (t >>> 15), t | 1)
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296
    }
}

function newGame(mode, seed, H) {
    var m = MODES[mode] || MODES.classic
    var h = H || W * 16 / 9
    return {
        mode: MODES[mode] ? mode : "classic",
        rand: makeRand(seed === undefined ? Date.now() : seed),
        H: h, G: gravity(h),
        t: 0, timeLeft: m.time, lives: m.lives,
        score: 0, sliced: 0, misses: 0, bombs: 0, bestCombo: 0,
        items: [], pieces: [], drops: [], queue: [],
        nextId: 1, spawnT: 0.6,
        comboHits: 0, comboT: -1, comboX: 0, comboY: 0,
        over: false, overT: 0, reason: "",
        events: []
    }
}

// Tyngdkraften följer höjden, så att en svamp alltid hänger i luften lika länge
function gravity(H) { return 1.25 * H }

function setHeight(s, H) {
    if (!H || Math.abs(H - s.H) < 0.01) return
    s.H = H
    s.G = gravity(H)
}

// 0 i början, 1 när det är som svårast
function difficulty(s) {
    if (s.mode === "classic") return Math.min(1, s.t / 120)
    var total = MODES[s.mode].time
    var d = Math.min(1, (total - s.timeLeft) / total)
    return s.mode === "zen" ? d * 0.6 : d
}

// ---- Kasta upp en svamp -------------------------------------------------------
// x0: startläge, x1: där den landar, apex: högsta punkt som andel av höjden
function launch(s, kind, x0, x1, apex) {
    var r = KINDS[kind].r
    var y0 = -r
    var top = Math.min(apex * s.H, s.H - r - 0.2)
    var vy = Math.sqrt(2 * s.G * (top - y0))
    var T = 2 * vy / s.G
    var it = {
        id: s.nextId++, kind: kind, r: r,
        x: x0, y: y0, vx: (x1 - x0) / T, vy: vy,
        rot: s.rand() * 360, vrot: (s.rand() < 0.5 ? -1 : 1) * (60 + s.rand() * 160),
        sliced: false, bomb: !!KINDS[kind].bomb
    }
    s.items.push(it)
    s.events.push({ type: "launch", kind: kind, bomb: it.bomb })
    return it
}

function randX(s, r) {
    var m = r + 0.3
    return m + s.rand() * (W - 2 * m)
}

function pick(s, list) { return list[Math.floor(s.rand() * list.length)] }

// En våg: några svampar på en gång eller i snabb följd, ibland en flugsvamp
function spawnWave(s) {
    var d = difficulty(s)
    var n
    if (s.mode === "classic") {
        n = 1 + Math.floor(s.rand() * (1 + 3 * d))
        if (d > 0.5 && s.rand() < 0.12) n = 5 + Math.floor(s.rand() * 2)
    } else {
        n = 2 + Math.floor(s.rand() * (2 + 2 * d))
    }
    var bombs = 0
    if (MODES[s.mode].bombs && s.t > 5) {
        var chance = s.mode === "classic" ? 0.22 + 0.33 * d : 0.35
        if (s.rand() < chance) bombs = (d > 0.7 && s.rand() < 0.3) ? 2 : 1
    }
    var burst = s.rand() < 0.5
    var list = []
    for (var i = 0; i < n; i++) list.push(pick(s, SHROOMS))
    for (var b = 0; b < bombs; b++) list.splice(Math.floor(s.rand() * (list.length + 1)), 0, "flyagaric")
    var wave = []
    for (var k = 0; k < list.length; k++) {
        var kind = list[k]
        var r = KINDS[kind].r
        var at = s.t + (burst ? k * 0.22 : s.rand() * 0.08)
        var x0, x1
        // En flugsvamp får inte följa samma bana som en svamp, för då går
        // svampen inte att klyva utan att träffa flugsvampen
        for (var tries = 0; tries < 10; tries++) {
            x0 = randX(s, r)
            x1 = Math.max(r + 0.3, Math.min(W - r - 0.3, x0 + (s.rand() * 2 - 1) * 4))
            var clash = false
            for (var o = 0; o < wave.length && !clash; o++) {
                var w = wave[o]
                if ((kind === "flyagaric") === (w.kind === "flyagaric")) continue
                if (Math.abs(w.at - at) < 0.35 && Math.abs(w.x0 - x0) < 1.8 && Math.abs(w.x1 - x1) < 1.8) clash = true
            }
            if (!clash) break
        }
        // Flugsvampar flyger lite lägre, så att de inte döljer allt annat
        var apex = kind === "flyagaric" ? 0.5 + s.rand() * 0.25 : 0.55 + s.rand() * 0.33
        var entry = { at: at, kind: kind, x0: x0, x1: x1, apex: apex }
        wave.push(entry)
        s.queue.push(entry)
    }
    var gap
    if (s.mode === "classic") gap = 2.5 * (1.1 - 0.45 * d) + s.rand() * 0.6 + (burst ? list.length * 0.22 : 0)
    else if (s.mode === "timed") gap = 1.55 - 0.55 * d + s.rand() * 0.4
    else gap = 1.7 - 0.4 * d + s.rand() * 0.4
    s.spawnT = gap
}

// ---- Ett tidssteg -------------------------------------------------------------
function step(s, dt) {
    s.t += dt
    stepPieces(s, dt)
    if (s.over) {
        // Efter slutet flyger svamparna färdigt, utom när en flugsvamp
        // klövs: då stannar allt ett ögonblick
        s.overT += dt
        if (s.reason !== "bomb") moveItems(s, dt, false)
        return
    }

    if (MODES[s.mode].time > 0) {
        var before = s.timeLeft
        s.timeLeft = Math.max(0, s.timeLeft - dt)
        if (Math.ceil(before) !== Math.ceil(s.timeLeft) && s.timeLeft <= 5 && s.timeLeft > 0)
            s.events.push({ type: "tick" })
        if (s.timeLeft <= 0) { finishCombo(s); end(s, "time"); return }
    }

    s.spawnT -= dt
    if (s.spawnT <= 0) spawnWave(s)
    if (s.queue.length) {
        var later = []
        for (var q = 0; q < s.queue.length; q++) {
            var w = s.queue[q]
            if (w.at <= s.t) launch(s, w.kind, w.x0, w.x1, w.apex)
            else later.push(w)
        }
        s.queue = later
    }

    moveItems(s, dt, true)
    if (s.over) return

    if (s.comboHits > 0 && s.t - s.comboT > COMBO_WINDOW) finishCombo(s)
}

// Flyttar svamparna ett steg. Svampar som fallit ut tas bort och räknas
// som missar om countMisses är sant.
function moveItems(s, dt, countMisses) {
    var keep = []
    for (var i = 0; i < s.items.length; i++) {
        var it = s.items[i]
        // Exakt kastbana inom steget, så att toppen hamnar där den ska
        it.x += it.vx * dt
        it.y += it.vy * dt - 0.5 * s.G * dt * dt
        it.vy -= s.G * dt
        it.rot += it.vrot * dt
        if (it.y < -it.r - 0.3 && it.vy < 0) {
            if (countMisses && !it.bomb) {
                miss(s, it)
                if (s.over) countMisses = false
            }
            continue
        }
        keep.push(it)
    }
    s.items = keep
}

function stepPieces(s, dt) {
    var g = s.G
    var p, keep = []
    for (var i = 0; i < s.pieces.length; i++) {
        p = s.pieces[i]
        p.vy -= g * dt
        p.x += p.vx * dt; p.y += p.vy * dt
        p.spin += p.vrot * dt
        if (p.y > -2) keep.push(p)
    }
    s.pieces = keep
    keep = []
    for (var j = 0; j < s.drops.length; j++) {
        p = s.drops[j]
        p.vy -= g * 0.7 * dt
        p.x += p.vx * dt; p.y += p.vy * dt
        p.life -= dt
        if (p.life > 0 && p.y > -1) keep.push(p)
    }
    s.drops = keep
}

function miss(s, it) {
    s.misses++
    s.events.push({ type: "miss", x: it.x, kind: it.kind })
    if (s.mode === "classic") {
        s.lives = Math.max(0, s.lives - 1)
        if (s.lives === 0) end(s, "lives")
    }
}

function end(s, reason) {
    if (s.over) return
    s.over = true
    s.overT = 0
    s.reason = reason
    s.events.push({ type: "over", reason: reason })
}

// ---- Snitt ----------------------------------------------------------------------
// Kortaste avståndet från punkten (px, py) till sträckan a–b
function segDist(ax, ay, bx, by, px, py) {
    var dx = bx - ax, dy = by - ay
    var len2 = dx * dx + dy * dy
    var u = len2 > 0 ? ((px - ax) * dx + (py - ay) * dy) / len2 : 0
    u = Math.max(0, Math.min(1, u))
    var cx = ax + u * dx - px, cy = ay + u * dy - py
    return Math.sqrt(cx * cx + cy * cy)
}

// Ett stycke av ett svep, från (ax, ay) till (bx, by) under tiden dt.
// Returnerar antalet svampar som klövs.
function slice(s, ax, ay, bx, by, dt) {
    if (s.over) return 0
    var dx = bx - ax, dy = by - ay
    var len = Math.sqrt(dx * dx + dy * dy)
    if (len < 1e-4 || len / Math.max(dt, 1e-3) < MIN_SPEED) return 0
    var hits = 0
    for (var i = 0; i < s.items.length; i++) {
        var it = s.items[i]
        if (it.sliced) continue
        if (segDist(ax, ay, bx, by, it.x, it.y) > it.r) continue
        it.sliced = true
        if (it.bomb) { hitBomb(s, it); if (s.over) break; continue }
        cut(s, it, dx / len, dy / len)
        hits++
    }
    if (hits || s.items.some(function (o) { return o.sliced })) {
        s.items = s.items.filter(function (o) { return !o.sliced })
    }
    return hits
}

function cut(s, it, ux, uy) {
    s.sliced++
    s.score += 1
    s.comboHits++
    s.comboT = s.t
    s.comboX = it.x; s.comboY = it.y
    // Snittets vinkel på skärmen (y nedåt) och normalen i världen
    var ang = Math.atan2(-uy, ux) * 180 / Math.PI
    var nx = -uy, ny = ux
    for (var h = 0; h < 2; h++) {
        var k = h === 0 ? 1 : -1
        if (s.pieces.length >= MAX_PIECES) s.pieces.shift()
        s.pieces.push({
            id: s.nextId++, kind: it.kind, half: h, r: it.r,
            x: it.x, y: it.y,
            vx: it.vx * 0.6 + nx * k * 1.6 + ux * 0.7,
            vy: Math.max(it.vy * 0.5, 0) + ny * k * 1.6 + uy * 0.7,
            cut: ang, rot: it.rot, spin: 0, vrot: k * (90 + s.rand() * 120)
        })
    }
    splash(s, it, 9, ux, uy)
    s.events.push({ type: "slice", kind: it.kind, x: it.x, y: it.y })
}

function splash(s, it, n, ux, uy) {
    for (var d = 0; d < n; d++) {
        if (s.drops.length >= MAX_DROPS) s.drops.shift()
        var a = s.rand() * Math.PI * 2
        var sp = 1.5 + s.rand() * 3.5
        s.drops.push({
            id: s.nextId++, kind: it.kind,
            x: it.x, y: it.y,
            vx: Math.cos(a) * sp + ux * 2, vy: Math.sin(a) * sp + uy * 2 + 1.5,
            size: 0.1 + s.rand() * 0.16, life: 0.5 + s.rand() * 0.5
        })
    }
}

function hitBomb(s, it) {
    s.bombs++
    splash(s, it, 18, 0, 0)
    s.events.push({ type: "bomb", x: it.x, y: it.y })
    if (s.mode === "classic") {
        s.bombX = it.x; s.bombY = it.y
        end(s, "bomb")
    } else {
        s.score = Math.max(0, s.score - BOMB_PENALTY)
        s.events.push({ type: "penalty", x: it.x, y: it.y, points: -BOMB_PENALTY })
    }
}

// Tre eller fler i samma svep ger lika många bonuspoäng
function finishCombo(s) {
    var n = s.comboHits
    s.comboHits = 0
    if (n >= 3) {
        s.score += n
        s.bestCombo = Math.max(s.bestCombo, n)
        s.events.push({ type: "combo", n: n, x: s.comboX, y: s.comboY })
    }
}

// ---- Datorspelare: testerna och skärmdumparna (--autoplay) ------------------
// Väljer den svamp som först riskerar att falla ut och drar ett kort snitt
// genom den i en riktning som inte rör någon flugsvamp. Returnerar
// [ax, ay, bx, by] eller null.
// reach: snittets halva längd i radier. patient: vänta tills svampen är nära toppen.
function bot(s, reach, patient) {
    if (s.over) return null
    if (s.botT && s.t < s.botT) return null
    var bombs = s.items.filter(function (o) { return o.bomb && !o.sliced })
    var targets = s.items.filter(function (o) {
        if (o.bomb || o.sliced || o.y < o.r || o.y > s.H - o.r) return false
        return patient ? o.vy < 2.5 : (o.vy < 1 || o.y > 0.4 * s.H)
    })
    targets.sort(function (a, b) { return (a.vy < 0 ? a.y : a.y + 20) - (b.vy < 0 ? b.y : b.y + 20) })
    var angles = [0, 45, 90, 135, 22, 68, 112, 158]
    for (var i = 0; i < targets.length; i++) {
        var t = targets[i]
        var L = t.r * (reach || 1.3)
        var best = null, bestHits = 0
        for (var a = 0; a < angles.length; a++) {
            var rad = angles[a] * Math.PI / 180
            var c = Math.cos(rad) * L, d = Math.sin(rad) * L
            var seg = [t.x - c, t.y - d, t.x + c, t.y + d]
            var safe = true
            for (var b = 0; b < bombs.length && safe; b++)
                if (segDist(seg[0], seg[1], seg[2], seg[3], bombs[b].x, bombs[b].y) < bombs[b].r + 0.35) safe = false
            if (!safe) continue
            var hits = 0
            for (var k = 0; k < s.items.length; k++) {
                var o = s.items[k]
                if (!o.bomb && segDist(seg[0], seg[1], seg[2], seg[3], o.x, o.y) <= o.r) hits++
            }
            if (hits > bestHits) { bestHits = hits; best = seg }
        }
        if (best) { s.botT = s.t + 0.12; return best }
    }
    return null
}
