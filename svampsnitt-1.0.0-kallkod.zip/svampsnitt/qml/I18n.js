.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

var languages = [
    { code: "en", name: "English" },
    { code: "sv", name: "Svenska" }
]

var sv = {
    // Meny och lägen
    "Slice the mushrooms – but never the fly agaric": "Klyv svamparna – men aldrig flugsvampen",
    "Slice a mushroom to start": "Klyv en svamp för att börja",
    "Classic": "Klassiskt",
    "Against the clock": "På tid",
    "Zen": "Zen",
    "Best: %1": "Rekord: %1",
    "Settings": "Inställningar",

    // Spelet
    "Swipe across the mushrooms to slice them": "Svep över svamparna för att klyva dem",
    "Don't let them fall – you have three lives": "Låt dem inte falla – du har tre liv",
    "A fly agaric costs you 10 points": "En flugsvamp kostar 10 poäng",
    "No fly agarics – just slice": "Inga flugsvampar – bara klyv",
    "Never slice a fly agaric!": "Klyv aldrig en flugsvamp!",
    "Combo ×%1": "Kombo ×%1",
    "Paused": "Paus",
    "Continue": "Fortsätt",
    "Quit game": "Avsluta omgången",
    "You sliced a fly agaric!": "Du klöv en flugsvamp!",
    "Three mushrooms fell": "Tre svampar föll",
    "Time's up!": "Tiden är slut!",
    "New record!": "Nytt rekord!",
    "sliced": "kluvna",
    "best combo": "största kombo",
    "Menu": "Meny",
    "Play again": "Spela igen",

    // Rekord
    "Records": "Rekord",
    "Best score": "Bästa poäng",
    "Mushrooms sliced": "Kluvna svampar",
    "Best combo": "Största kombo",
    "Games": "Omgångar",
    "Top games": "Bästa omgångarna",
    "No games yet. Your best games will show up here.": "Inga omgångar än. Dina bästa omgångar visas här.",
    "%1 sliced": "%1 kluvna",

    // Inställningar
    "Theme": "Tema",
    "Automatic": "Automatiskt",
    "Light (day)": "Ljust (dag)",
    "Dark (evening)": "Mörkt (kväll)",
    "Season": "Årstid",
    "Automatic (follows the calendar)": "Automatiskt (följer kalendern)",
    "Summer": "Sommar",
    "Autumn": "Höst",
    "Winter": "Vinter",
    "Language": "Språk",
    "Automatic (system language)": "Automatiskt (systemets språk)",
    "Sound": "Ljud",
    "Background sounds": "Bakgrundsljud",
    "Sound effects": "Ljudeffekter",
    "Clear records": "Rensa rekord",
    "Clear records?": "Rensa rekorden?",
    "All saved games and best scores will be deleted.": "Alla sparade omgångar och rekord tas bort.",
    "Clear": "Rensa",
    "Cancel": "Avbryt",
    "How to play": "Så spelar du",
    "Swipe across the mushrooms to slice them. Slice three or more in one swipe for a combo, which gives as many bonus points.":
        "Svep över svamparna för att klyva dem. Klyver du tre eller fler i samma svep blir det en kombo, som ger lika många extrapoäng.",
    "Classic: you have three lives, and every mushroom that falls costs one. Slicing a fly agaric ends the game.":
        "Klassiskt: du har tre liv, och varje svamp som faller kostar ett. Klyver du en flugsvamp är omgången slut.",
    "Against the clock: 60 seconds, and a fly agaric costs 10 points. Zen: 90 seconds without fly agarics.":
        "På tid: 60 sekunder, och en flugsvamp kostar 10 poäng. Zen: 90 sekunder utan flugsvampar.",
    "About": "Om",
    "Slice the mushrooms that fly up from the moss. An original game in the slicing genre – all graphics and sounds are made for this game.":
        "Klyv svamparna som flyger upp ur mossan. Ett eget spel i genren där man klyver saker i luften – all grafik och alla ljud är gjorda för det här spelet.",
    "The background sounds come from Kottslungan by the same author.": "Bakgrundsljuden kommer från Kottslungan av samma upphovsperson.",
    "Version %1": "Version %1"
}

var tables = { sv: sv }

function systemLanguage(localeName) {
    return (localeName || "en").substring(0, 2) === "sv" ? "sv" : "en"
}

function tr(s, lang) {
    var t = tables[lang]
    return (t && t[s] !== undefined) ? t[s] : s
}
