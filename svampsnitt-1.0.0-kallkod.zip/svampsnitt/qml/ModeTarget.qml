// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3

// En svamp i en ring på menyn. Klyv den (eller tryck på den) för att välja läget.
Item {
    id: target
    property string kind: "chanterelle"
    property string title: ""
    property string subtitle: ""
    property bool cut: false
    property real cutAngle: 0
    property real spread: 0
    readonly property real ringSize: width
    readonly property point center: Qt.point(width / 2, width / 2)
    signal chosen()

    height: width + titleLabel.height + subLabel.height + units.gu(1)

    function split(angle) {
        if (cut) return
        cutAngle = angle
        cut = true
        splitAnim.restart()
    }
    function reset() { cut = false; spread = 0; splitAnim.stop() }

    Rectangle {
        id: ring
        width: target.ringSize; height: width
        radius: width / 2
        color: "#38FFFFFF"
        border.color: "#D0FFFFFF"
        border.width: units.dp(3)
    }

    Image {
        id: whole
        anchors.centerIn: ring
        width: ring.width * 0.74; height: width
        source: "../assets/" + target.kind + ".svg"
        sourceSize: Qt.size(160, 160)
        visible: !target.cut
        SequentialAnimation on rotation {
            loops: Animation.Infinite
            running: Qt.application.state === Qt.ApplicationActive
            NumberAnimation { from: -7; to: 7; duration: 1500; easing.type: Easing.InOutSine }
            NumberAnimation { from: 7; to: -7; duration: 1500; easing.type: Easing.InOutSine }
        }
    }

    Item {
        anchors.centerIn: ring
        width: whole.width; height: width
        visible: target.cut
        rotation: target.cutAngle
        PieceSprite {
            width: parent.width; height: width
            y: -target.spread; x: target.spread * 0.3
            visible: true; half: 0
            source: whole.source
            imageRotation: whole.rotation - target.cutAngle
            rotation: -target.spread * 0.4
        }
        PieceSprite {
            width: parent.width; height: width
            y: target.spread; x: -target.spread * 0.3
            visible: true; half: 1
            source: whole.source
            imageRotation: whole.rotation - target.cutAngle
            rotation: target.spread * 0.4
        }
    }

    SequentialAnimation {
        id: splitAnim
        NumberAnimation { target: target; property: "spread"; from: 0; to: units.gu(3); duration: 380; easing.type: Easing.OutCubic }
        PauseAnimation { duration: 120 }
        ScriptAction { script: target.chosen() }
    }

    Label {
        id: titleLabel
        anchors { horizontalCenter: ring.horizontalCenter; top: ring.bottom; topMargin: units.gu(0.8) }
        width: Math.max(target.width + units.gu(2), implicitWidth)
        horizontalAlignment: Text.AlignHCenter
        text: target.title
        font.weight: Font.Bold
        color: "#FFFFFF"
        style: Text.Outline; styleColor: "#3A2A10"
    }
    Label {
        id: subLabel
        anchors { horizontalCenter: ring.horizontalCenter; top: titleLabel.bottom }
        text: target.subtitle
        textSize: Label.Small
        color: "#FFFFFF"
        style: Text.Outline; styleColor: "#3A2A10"
        height: text === "" ? 0 : implicitHeight
    }
}
