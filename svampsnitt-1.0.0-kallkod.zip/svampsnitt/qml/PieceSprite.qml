// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12

// En halva av en kluven svamp. Hela biten vrids efter snittets vinkel, och
// bilden inuti vrids tillbaka, så att halvorna först ligger exakt där svampen
// var och sedan glider isär längs snittet.
Item {
    id: piece
    property int objectId: -1
    property string source: ""
    property int half: 0                 // 0 = ovanför snittet, 1 = under
    property real imageRotation: 0
    visible: false

    Item {
        clip: true
        width: piece.width
        height: piece.height / 2
        y: piece.half === 0 ? 0 : piece.height / 2
        Image {
            width: piece.width
            height: piece.height
            y: piece.half === 0 ? 0 : -piece.height / 2
            source: piece.source
            sourceSize: Qt.size(160, 160)
            rotation: piece.imageRotation
            smooth: true
        }
    }
}
