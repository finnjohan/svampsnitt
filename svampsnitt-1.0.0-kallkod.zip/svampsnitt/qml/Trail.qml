// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12

// Spåret efter fingret: några få rundade rektanglar mellan de senaste
// punkterna, som smalnar av och tonar bort. Ingen Canvas, så det går via GPU:n.
Item {
    id: trail
    property real life: 0.2                     // sekunder innan en punkt försvinner
    property real thickness: 14
    property color glowColor: "#FFF4C2"
    property color coreColor: "#FFFFFF"
    property var points: []                     // { x, y, t }
    readonly property int segments: 16
    enabled: false

    function begin(x, y) { points = [{ x: x, y: y, t: Date.now() }]; redraw() }
    function add(x, y) {
        var p = points
        p.push({ x: x, y: y, t: Date.now() })
        if (p.length > segments + 1) p.shift()
        points = p
        redraw()
    }
    // Ett helt snitt på en gång (datorspelaren)
    function stroke(ax, ay, bx, by) {
        var now = Date.now(), list = []
        for (var i = 0; i <= 4; i++)
            list.push({ x: ax + (bx - ax) * i / 4, y: ay + (by - ay) * i / 4, t: now - (4 - i) * 12 })
        points = list
        redraw()
    }

    Timer {
        interval: 16; repeat: true
        running: trail.points.length > 0
        onTriggered: trail.redraw()
    }

    function redraw() {
        var now = Date.now()
        var p = points.filter(function (q) { return (now - q.t) / 1000 < trail.life })
        if (p.length !== points.length) points = p
        for (var i = 0; i < segments; i++) {
            var seg = rep.itemAt(i)
            if (!seg) continue
            if (i >= p.length - 1) { seg.visible = false; continue }
            var a = p[i], b = p[i + 1]
            var dx = b.x - a.x, dy = b.y - a.y
            var len = Math.sqrt(dx * dx + dy * dy)
            var age = (now - b.t) / 1000 / life
            var w = thickness * Math.max(0.15, (i + 1) / (p.length - 1)) * (1 - age * 0.6)
            seg.visible = len > 0.5
            // Vridpunkten (vänster mitt) ligger på a; rektangeln sticker ut
            // en halv bredd förbi b, så att lederna inte får hack
            seg.width = len + w / 2
            seg.height = w
            seg.radius = w / 2
            seg.x = a.x
            seg.y = a.y - w / 2
            seg.rotation = Math.atan2(dy, dx) * 180 / Math.PI
            seg.opacity = Math.max(0, 1 - age)
        }
    }

    Repeater {
        id: rep
        model: trail.segments
        Rectangle {
            visible: false
            antialiasing: true
            transformOrigin: Item.Left
            color: trail.glowColor
            Rectangle {
                anchors.centerIn: parent
                width: parent.width - parent.height * 0.5
                height: parent.height * 0.45
                radius: height / 2
                antialiasing: true
                color: trail.coreColor
            }
        }
    }
}
