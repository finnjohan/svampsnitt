// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3

Page {
    id: page
    // Ingen rubrikrad: spelet ska fylla hela skärmen
    header: Item { height: 0; visible: false }

    property string mode: "classic"
    property bool paused: false
    property bool showResult: false
    property int finalScore: 0
    property int finalSliced: 0
    property int finalCombo: 0
    property string finalReason: ""
    property bool newBest: false
    property bool showHelp: root.stats.games < 3

    readonly property color textColor: "#FFFFFF"
    readonly property color outline: "#3A2A10"

    function restart() {
        showResult = false
        paused = false
        showHelp = root.stats.games < 3
        helpTimer.restart()
        game.start()
    }

    function clock(sec) {
        var s = Math.ceil(sec)
        return Math.floor(s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60)
    }

    GameView {
        id: game
        anchors.fill: parent
        mode: page.mode
        autoplay: root.autoplay
        seed: root.seed
        season: root.season
        night: root.isDark
        running: !page.paused && !page.showResult && stack.currentPage === page
        onSound: root.playSound(name)
        Component.onCompleted: start()
        onFinished: {
            page.finalScore = score
            page.finalSliced = sliced
            page.finalCombo = bestCombo
            page.finalReason = reason
            page.newBest = score > 0 && score > root.best(page.mode)
            root.saveRun(page.mode, score, sliced, bestCombo)
            page.showResult = true
        }
    }

    // Paus när appen inte är aktiv
    Connections {
        target: Qt.application
        function onStateChanged() { if (Qt.application.state !== Qt.ApplicationActive && !page.showResult && !game.over) page.paused = true }
    }

    // ---- Överst: poäng, liv eller tid, paus -------------------------------------
    Column {
        anchors { left: parent.left; top: parent.top; margins: units.gu(1.5) }
        Row {
            spacing: units.gu(0.8)
            Image {
                anchors.verticalCenter: parent.verticalCenter
                source: "../assets/chanterelle.svg"
                width: units.gu(4); height: width
                sourceSize: Qt.size(96, 96)
            }
            Label {
                anchors.verticalCenter: parent.verticalCenter
                text: game.score
                font.pixelSize: units.gu(4.5)
                font.weight: Font.Bold
                color: page.textColor
                style: Text.Outline; styleColor: page.outline
            }
        }
        Label {
            visible: root.best(page.mode) > 0
            text: root.tr("Best: %1").arg(root.best(page.mode))
            textSize: Label.Small
            color: page.textColor
            style: Text.Outline; styleColor: page.outline
        }
    }

    Row {
        anchors { right: parent.right; top: parent.top; margins: units.gu(1.5) }
        spacing: units.gu(1.2)
        layoutDirection: Qt.RightToLeft

        RoundButton {
            iconName: "media-playback-pause"
            visible: !page.showResult
            onClicked: page.paused = true
        }
        // Tre liv i klassiskt läge: en kantarell per liv, grå med kryss när den är förlorad
        Row {
            visible: page.mode === "classic"
            anchors.verticalCenter: parent.verticalCenter
            spacing: units.gu(0.4)
            Repeater {
                model: 3
                Item {
                    width: units.gu(3.6); height: width
                    readonly property bool lost: index >= game.lives
                    Image {
                        anchors.fill: parent
                        source: "../assets/chanterelle.svg"
                        sourceSize: Qt.size(96, 96)
                        opacity: parent.lost ? 0.35 : 1
                    }
                    Icon {
                        anchors.centerIn: parent
                        visible: parent.lost
                        name: "close"
                        color: "#E53935"
                        width: parent.width * 0.9; height: width
                    }
                }
            }
        }
        Label {
            visible: page.mode !== "classic"
            anchors.verticalCenter: parent.verticalCenter
            text: page.clock(game.timeLeft)
            font.pixelSize: units.gu(4)
            font.weight: Font.Bold
            color: game.timeLeft <= 5 ? "#FF8A80" : page.textColor
            style: Text.Outline; styleColor: page.outline
        }
    }

    // Hjälp de första omgångarna
    Timer { id: helpTimer; interval: 4500; running: true; onTriggered: page.showHelp = false }
    Rectangle {
        anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: units.gu(11) }
        visible: page.showHelp && !page.showResult && !page.paused
        width: helpCol.width + units.gu(3); height: helpCol.height + units.gu(2)
        radius: units.gu(1.5)
        color: "#A0000000"
        Column {
            id: helpCol
            anchors.centerIn: parent
            spacing: units.gu(0.5)
            Label { anchors.horizontalCenter: parent.horizontalCenter; text: root.tr("Swipe across the mushrooms to slice them"); color: "#FFFFFF" }
            Label {
                anchors.horizontalCenter: parent.horizontalCenter
                text: page.mode === "classic" ? root.tr("Don't let them fall – you have three lives")
                    : page.mode === "timed" ? root.tr("A fly agaric costs you 10 points")
                    : root.tr("No fly agarics – just slice")
                color: "#FFFFFF"
            }
            Label {
                anchors.horizontalCenter: parent.horizontalCenter
                visible: page.mode === "classic"
                text: root.tr("Never slice a fly agaric!")
                color: "#FFAB91"
                font.weight: Font.Bold
            }
        }
    }

    // ---- Paus ------------------------------------------------------------------
    Rectangle {
        anchors.fill: parent
        visible: page.paused && !page.showResult
        color: "#90000000"
        MouseArea { anchors.fill: parent }
        Column {
            anchors.centerIn: parent
            spacing: units.gu(2)
            Label {
                anchors.horizontalCenter: parent.horizontalCenter
                text: root.tr("Paused")
                font.pixelSize: units.gu(4); font.weight: Font.Bold
                color: "#FFFFFF"
            }
            Button {
                anchors.horizontalCenter: parent.horizontalCenter
                width: units.gu(22)
                text: root.tr("Continue")
                color: "#E8862A"
                onClicked: page.paused = false
            }
            Button {
                anchors.horizontalCenter: parent.horizontalCenter
                width: units.gu(22)
                text: root.tr("Quit game")
                onClicked: stack.pop()
            }
        }
    }

    // ---- Resultat --------------------------------------------------------------
    Rectangle {
        anchors.fill: parent
        visible: page.showResult
        color: "#80000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width - units.gu(4), units.gu(40))
            height: resultCol.height + units.gu(5)
            radius: units.gu(2)
            color: theme.palette.normal.background
            border.color: theme.palette.normal.base

            Column {
                id: resultCol
                anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: units.gu(2.5) }
                spacing: units.gu(1.5)
                Label {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: page.finalReason === "bomb" ? root.tr("You sliced a fly agaric!")
                        : page.finalReason === "lives" ? root.tr("Three mushrooms fell")
                        : root.tr("Time's up!")
                    textSize: Label.Large
                    font.weight: Font.Bold
                    width: Math.min(implicitWidth, parent.width)
                    wrapMode: Text.WordWrap
                    horizontalAlignment: Text.AlignHCenter
                }
                Label {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: page.newBest
                    text: root.tr("New record!")
                    font.weight: Font.Bold
                    color: theme.palette.normal.positive
                }
                Label {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: page.finalScore
                    font.pixelSize: units.gu(6)
                    font.weight: Font.Bold
                }
                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: units.gu(3)
                    Column {
                        Label { anchors.horizontalCenter: parent.horizontalCenter; text: page.finalSliced; font.weight: Font.Bold; textSize: Label.Large }
                        Label { anchors.horizontalCenter: parent.horizontalCenter; text: root.tr("sliced"); textSize: Label.Small; color: theme.palette.normal.backgroundSecondaryText }
                    }
                    Column {
                        Label { anchors.horizontalCenter: parent.horizontalCenter; text: page.finalCombo > 0 ? "×" + page.finalCombo : "–"; font.weight: Font.Bold; textSize: Label.Large }
                        Label { anchors.horizontalCenter: parent.horizontalCenter; text: root.tr("best combo"); textSize: Label.Small; color: theme.palette.normal.backgroundSecondaryText }
                    }
                }
                Label {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: !page.newBest && root.best(page.mode) > 0
                    text: root.tr("Best: %1").arg(root.best(page.mode))
                    color: theme.palette.normal.backgroundSecondaryText
                }
                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: units.gu(1.5)
                    Button {
                        text: root.tr("Menu")
                        onClicked: stack.pop()
                    }
                    Button {
                        text: root.tr("Play again")
                        color: "#E8862A"
                        onClicked: page.restart()
                    }
                }
            }
        }
    }
}
