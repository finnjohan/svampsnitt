// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3

Page {
    id: page
    header: PageHeader { id: header; title: root.tr("Records") }

    function dateText(ts) {
        return new Date(ts).toLocaleDateString(Qt.locale(root.lang === "sv" ? "sv_SE" : "en_GB"), Locale.ShortFormat)
    }

    Flickable {
        anchors { top: header.bottom; left: parent.left; right: parent.right; bottom: parent.bottom }
        contentHeight: content.height + units.gu(4)
        clip: true

        Column {
            id: content
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: units.gu(2) }
            spacing: units.gu(1.5)

            Label { text: root.tr("Best score"); font.weight: Font.Medium }
            Row {
                width: parent.width
                spacing: units.gu(1)
                Repeater {
                    model: [
                        { mode: "classic", kind: "chanterelle" },
                        { mode: "timed", kind: "porcini" },
                        { mode: "zen", kind: "birch" }
                    ]
                    Rectangle {
                        width: (content.width - units.gu(2)) / 3
                        height: units.gu(12)
                        radius: units.gu(1)
                        color: theme.palette.normal.foreground
                        Column {
                            anchors.centerIn: parent
                            spacing: units.gu(0.3)
                            Image {
                                anchors.horizontalCenter: parent.horizontalCenter
                                source: "../assets/" + modelData.kind + ".svg"
                                width: units.gu(3.5); height: width
                                sourceSize: Qt.size(96, 96)
                            }
                            Label { anchors.horizontalCenter: parent.horizontalCenter; text: root.best(modelData.mode); textSize: Label.Large; font.weight: Font.Bold }
                            Label { anchors.horizontalCenter: parent.horizontalCenter; text: root.modeName(modelData.mode); textSize: Label.Small
                                    color: theme.palette.normal.backgroundSecondaryText }
                        }
                    }
                }
            }

            Grid {
                width: parent.width
                columns: 3
                spacing: units.gu(1)
                Repeater {
                    model: [
                        { value: root.stats.sliced, label: root.tr("Mushrooms sliced") },
                        { value: root.stats.combo > 0 ? "×" + root.stats.combo : "–", label: root.tr("Best combo") },
                        { value: root.stats.games, label: root.tr("Games") }
                    ]
                    Rectangle {
                        width: (content.width - units.gu(2)) / 3
                        height: units.gu(8)
                        radius: units.gu(1)
                        color: theme.palette.normal.foreground
                        Column {
                            anchors.centerIn: parent
                            Label { anchors.horizontalCenter: parent.horizontalCenter; text: modelData.value; textSize: Label.Large; font.weight: Font.Bold }
                            Label { anchors.horizontalCenter: parent.horizontalCenter; text: modelData.label; textSize: Label.Small
                                    color: theme.palette.normal.backgroundSecondaryText }
                        }
                    }
                }
            }

            Item { width: 1; height: units.gu(0.5) }
            Label { text: root.tr("Top games"); font.weight: Font.Medium }
            Label {
                visible: root.topRuns.length === 0
                width: parent.width
                wrapMode: Text.WordWrap
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("No games yet. Your best games will show up here.")
            }
            Column {
                width: parent.width
                Repeater {
                    model: root.topRuns
                    ListItem {
                        width: parent.width
                        height: units.gu(6)
                        divider.visible: index < root.topRuns.length - 1
                        Label {
                            id: rank
                            anchors { left: parent.left; verticalCenter: parent.verticalCenter }
                            width: units.gu(4)
                            text: (index + 1) + "."
                            font.weight: Font.Bold
                            color: index === 0 ? "#E8862A" : theme.palette.normal.backgroundText
                        }
                        Column {
                            anchors { left: rank.right; verticalCenter: parent.verticalCenter }
                            Label { text: modelData.score; font.weight: Font.Bold }
                            Label {
                                text: root.modeName(modelData.mode) + " · " + root.tr("%1 sliced").arg(modelData.sliced)
                                textSize: Label.Small
                                color: theme.palette.normal.backgroundSecondaryText
                            }
                        }
                        Label {
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            text: page.dateText(modelData.ts)
                            textSize: Label.Small
                            color: theme.palette.normal.backgroundSecondaryText
                        }
                    }
                }
            }
        }
    }
}
