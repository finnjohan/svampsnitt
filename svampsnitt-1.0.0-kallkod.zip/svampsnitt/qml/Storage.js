.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
.import QtQuick.LocalStorage 2.0 as Sql

var _db = null
var _name = "svampsnitt"

function useDatabase(name) { _name = name; _db = null }

function db() {
    if (_db) return _db
    _db = Sql.LocalStorage.openDatabaseSync(_name, "1.0", "Svampsnitt", 1000000)
    _db.transaction(function (tx) {
        tx.executeSql("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
        tx.executeSql("CREATE TABLE IF NOT EXISTS runs (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, " +
                      "mode TEXT NOT NULL, score INTEGER NOT NULL, sliced INTEGER NOT NULL, combo INTEGER NOT NULL)")
    })
    return _db
}

function setting(key, fallback) {
    var v = fallback
    db().readTransaction(function (tx) {
        var rs = tx.executeSql("SELECT value FROM settings WHERE key = ?", [key])
        if (rs.rows.length > 0 && rs.rows.item(0).value !== null) v = rs.rows.item(0).value
    })
    return v
}

function setSetting(key, value) {
    db().transaction(function (tx) {
        tx.executeSql("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", [key, String(value)])
    })
}

function saveRun(mode, score, sliced, combo, ts) {
    db().transaction(function (tx) {
        tx.executeSql("INSERT INTO runs (ts, mode, score, sliced, combo) VALUES (?, ?, ?, ?, ?)",
                      [ts || Date.now(), mode, score, sliced, combo])
    })
}

function emptyStats() {
    return { best: { classic: 0, timed: 0, zen: 0 }, sliced: 0, games: 0, combo: 0 }
}

// Bästa poäng per läge, antal kluvna svampar, antal omgångar och största kombo
function stats() {
    var out = emptyStats()
    db().readTransaction(function (tx) {
        var rs = tx.executeSql("SELECT mode, MAX(score) AS best FROM runs GROUP BY mode")
        for (var i = 0; i < rs.rows.length; i++) out.best[rs.rows.item(i).mode] = rs.rows.item(i).best || 0
        var t = tx.executeSql("SELECT SUM(sliced) AS sliced, COUNT(*) AS games, MAX(combo) AS combo FROM runs")
        if (t.rows.length > 0) {
            var r = t.rows.item(0)
            out.sliced = r.sliced || 0
            out.games = r.games || 0
            out.combo = r.combo || 0
        }
    })
    return out
}

// De bästa omgångarna, högst n stycken
function topRuns(n) {
    var out = []
    db().readTransaction(function (tx) {
        var rs = tx.executeSql("SELECT * FROM runs ORDER BY score DESC, ts ASC LIMIT ?", [n])
        for (var i = 0; i < rs.rows.length; i++) out.push(rs.rows.item(i))
    })
    return out
}

function resetRuns() {
    db().transaction(function (tx) { tx.executeSql("DELETE FROM runs") })
}
