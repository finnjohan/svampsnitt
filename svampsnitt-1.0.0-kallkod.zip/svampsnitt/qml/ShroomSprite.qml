// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12

// En hel svamp i luften. sourceSize är fast, så att SVG:n bara ritas en gång
// och sedan skalas och vrids av grafikkortet.
Image {
    property int objectId: -1
    visible: false
    smooth: true
    sourceSize: Qt.size(160, 160)
}
