// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Logic.js" as Logic

// Spelplanen: skogsbakgrund, svamparna i luften, halvor, saft och fingrets
// spår. Logic.js sköter reglerna; här ritas läget varje bildruta med vanliga
// QML-objekt som återanvänds.
Item {
    id: view
    clip: true

    property string mode: "classic"
    property bool running: true
    property bool autoplay: false           // datorspelaren klyver (skärmdumpar)
    property int seed: -1
    property string season: "summer"
    property bool night: false

    // Läget i spelet, för rubrikraden
    property int score: 0
    property int lives: 0
    property int sliced: 0
    property int bestCombo: 0
    property real timeLeft: 0
    property bool over: false
    property string reason: ""

    signal sound(string name)
    signal finished()

    // Skala: världen är Logic.W enheter bred
    readonly property real k: width / Logic.W
    function px(x) { return x * k }
    function py(y) { return height - y * k }
    function wx(x) { return x / k }
    function wy(y) { return (height - y) / k }

    property var game: null
    property var sprites: ({})          // svampens id → ShroomSprite
    property var pieceSprites: ({})     // halvans id → PieceSprite
    property var spritePool: []
    property var piecePool: []
    property real lastTick: 0

    readonly property var juice: ({
        chanterelle: "#F4B830", porcini: "#E8D7A6", trumpet: "#6B5646",
        birch: "#EDE2CB", puffball: "#9C8B62", flyagaric: "#FFFFFF"
    })

    function start() {
        game = Logic.newGame(mode, seed >= 0 ? seed : Date.now() % 2147483647, height / Math.max(1, k))
        for (var id in sprites) releaseSprite(sprites[id])
        for (var pid in pieceSprites) releasePiece(pieceSprites[pid])
        sprites = ({}); pieceSprites = ({})
        over = false
        reason = ""
        flash.opacity = 0
        lastTick = Date.now()
        sound("start")
        render()
    }

    onHeightChanged: if (game && k > 0) Logic.setHeight(game, height / k)

    // ---- Spelloopen ----------------------------------------------------------
    Timer {
        id: loop
        interval: 16; repeat: true
        running: view.running && view.game !== null && Qt.application.state === Qt.ApplicationActive
        onRunningChanged: view.lastTick = Date.now()
        onTriggered: view.tick()
    }

    function tick() {
        var now = Date.now()
        var dt = Math.min(0.05, (now - lastTick) / 1000)
        lastTick = now
        var g = game
        var steps = Math.max(1, Math.ceil(dt / (1 / 60)))
        for (var i = 0; i < steps; i++) {
            if (autoplay) {
                var seg = Logic.bot(g, 2.2, true)
                if (seg) {
                    Logic.slice(g, seg[0], seg[1], seg[2], seg[3], 1 / 60)
                    // Spåret ritas lite längre än snittet, som ett riktigt svep
                    var ex = (seg[2] - seg[0]) * 0.6, ey = (seg[3] - seg[1]) * 0.6
                    trail.stroke(px(seg[0] - ex), py(seg[1] - ey), px(seg[2] + ex), py(seg[3] + ey))
                }
            }
            Logic.step(g, dt / steps)
        }
        handleEvents(g)
        render()
    }

    function handleEvents(g) {
        for (var e = 0; e < g.events.length; e++) {
            var ev = g.events[e]
            switch (ev.type) {
            case "launch": sound("launch"); break
            case "slice": sound("slice"); break
            case "tick": sound("tick"); break
            case "miss":
                sound("miss")
                missComp.createObject(view, { x: px(ev.x) - units.gu(2), y: height - units.gu(6) })
                break
            case "combo":
                sound("combo")
                showPopup(root.tr("Combo ×%1").arg(ev.n) + "\n+" + ev.n, ev.x, ev.y, "#FFE082")
                break
            case "penalty":
                showPopup("−" + Math.abs(ev.points), ev.x, ev.y, "#FF8A80")
                break
            case "bomb":
                sound("bomb")
                flash.color = "#FFFFFF"
                flashAnim.restart()
                break
            case "over":
                over = true
                reason = ev.reason
                if (ev.reason !== "bomb") sound("over")
                overTimer.restart()
                break
            }
        }
        g.events = []
    }

    function showPopup(text, x, y, color) {
        var p = popupComp.createObject(view, { text: text, color: color, startY: py(y) - units.gu(4) })
        p.x = Math.max(units.gu(1), Math.min(width - p.width - units.gu(1), px(x) - p.width / 2))
    }

    Timer {
        id: overTimer
        interval: 1100
        onTriggered: view.finished()
    }

    // ---- Bakgrund ----------------------------------------------------------------
    Image {
        anchors.fill: parent
        source: "../assets/bg-" + view.season + ".svg"
        sourceSize: Qt.size(720, 1280)
        fillMode: Image.PreserveAspectCrop
        smooth: true
    }
    Rectangle {          // kvällsljus
        anchors.fill: parent
        visible: view.night
        color: view.season === "winter" ? "#0A1E3A" : "#1A1E46"
        opacity: 0.42
    }

    // ---- Svampar, halvor och saft -------------------------------------------------
    Item { id: pieceLayer; anchors.fill: parent }
    Item { id: shroomLayer; anchors.fill: parent }
    Item {
        id: dropLayer
        anchors.fill: parent
        Repeater {
            id: dropRep
            model: Logic.MAX_DROPS
            Rectangle { visible: false; antialiasing: true }
        }
    }

    Component { id: spriteComp; ShroomSprite {} }
    Component { id: pieceComp; PieceSprite {} }
    Component { id: popupComp; Popup {} }
    Component {
        id: missComp
        Icon {
            id: mark
            name: "close"
            color: "#E53935"
            width: units.gu(4); height: width
            NumberAnimation on opacity { from: 1; to: 0; duration: 1200; easing.type: Easing.InQuad; onFinished: mark.destroy() }
        }
    }

    function obtainSprite(it) {
        var sp = spritePool.length ? spritePool.pop() : spriteComp.createObject(shroomLayer)
        sp.objectId = it.id
        sp.source = "../assets/" + it.kind + ".svg"
        sp.visible = true
        return sp
    }
    function releaseSprite(sp) { sp.visible = false; sp.objectId = -1; spritePool.push(sp) }
    function obtainPiece(p) {
        var sp = piecePool.length ? piecePool.pop() : pieceComp.createObject(pieceLayer)
        sp.objectId = p.id
        sp.source = "../assets/" + p.kind + ".svg"
        sp.half = p.half
        sp.visible = true
        return sp
    }
    function releasePiece(sp) { sp.visible = false; sp.objectId = -1; piecePool.push(sp) }

    // ---- Rita en bildruta -----------------------------------------------------------
    function render() {
        var g = game
        if (!g) return
        var seen = {}, i, size, sp

        for (i = 0; i < g.items.length; i++) {
            var it = g.items[i]
            seen[it.id] = true
            sp = sprites[it.id]
            if (!sp) { sp = obtainSprite(it); sprites[it.id] = sp }
            size = it.r * 2.3 * k
            sp.width = size; sp.height = size
            sp.x = px(it.x) - size / 2
            sp.y = py(it.y) - size / 2
            sp.rotation = it.rot
        }
        for (var id in sprites) if (!seen[id]) { releaseSprite(sprites[id]); delete sprites[id] }

        seen = {}
        for (i = 0; i < g.pieces.length; i++) {
            var p = g.pieces[i]
            seen[p.id] = true
            sp = pieceSprites[p.id]
            if (!sp) { sp = obtainPiece(p); pieceSprites[p.id] = sp }
            size = p.r * 2.3 * k
            sp.width = size; sp.height = size
            sp.x = px(p.x) - size / 2
            sp.y = py(p.y) - size / 2
            sp.rotation = p.cut + p.spin
            sp.imageRotation = p.rot - p.cut
        }
        for (var pid in pieceSprites) if (!seen[pid]) { releasePiece(pieceSprites[pid]); delete pieceSprites[pid] }

        for (i = 0; i < dropRep.count; i++) {
            var r = dropRep.itemAt(i)
            if (i >= g.drops.length) { r.visible = false; continue }
            var d = g.drops[i]
            var ds = d.size * k
            r.visible = true
            r.width = ds; r.height = ds; r.radius = ds / 2
            r.x = px(d.x) - ds / 2; r.y = py(d.y) - ds / 2
            r.color = d.kind === "flyagaric" && d.id % 3 === 0 ? "#D62B1F" : juice[d.kind]
            r.opacity = Math.min(1, d.life * 2.5)
        }

        score = g.score
        lives = g.lives
        sliced = g.sliced
        bestCombo = g.bestCombo
        timeLeft = g.timeLeft
    }

    // ---- Blixt när en flugsvamp klyvs ----------------------------------------------
    Rectangle {
        id: flash
        anchors.fill: parent
        color: "#FFFFFF"
        opacity: 0
        SequentialAnimation {
            id: flashAnim
            NumberAnimation { target: flash; property: "opacity"; to: 0.85; duration: 60 }
            NumberAnimation { target: flash; property: "opacity"; to: 0; duration: 700; easing.type: Easing.OutQuad }
        }
    }

    // ---- Fingret ------------------------------------------------------------------------
    Trail {
        id: trail
        anchors.fill: parent
        thickness: units.gu(1.8)
        glowColor: view.night ? "#B3E5FC" : "#FFF4C2"
    }

    MouseArea {
        anchors.fill: parent
        enabled: !view.autoplay
        property real lx: 0
        property real ly: 0
        property double lt: 0
        onPressed: {
            lx = mouse.x; ly = mouse.y; lt = Date.now()
            trail.begin(mouse.x, mouse.y)
        }
        onPositionChanged: {
            var now = Date.now()
            if (view.game && view.running)
                Logic.slice(view.game, view.wx(lx), view.wy(ly), view.wx(mouse.x), view.wy(mouse.y), (now - lt) / 1000)
            trail.add(mouse.x, mouse.y)
            lx = mouse.x; ly = mouse.y; lt = now
        }
    }
}
