// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Logic.js" as Logic

Page {
    id: page
    // Ingen rubrikrad: skogen fyller hela skärmen
    header: Item { height: 0; visible: false }

    Image {
        anchors.fill: parent
        source: "../assets/bg-" + root.season + ".svg"
        sourceSize: Qt.size(720, 1280)
        fillMode: Image.PreserveAspectCrop
    }
    Rectangle {
        anchors.fill: parent
        visible: root.isDark
        color: root.season === "winter" ? "#0A1E3A" : "#1A1E46"
        opacity: 0.42
    }
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0; color: "#70000000" }
            GradientStop { position: 0.4; color: "#10000000" }
            GradientStop { position: 1; color: "#40000000" }
        }
    }

    Column {
        anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: parent.height * 0.09 }
        spacing: units.gu(1.5)
        Label {
            anchors.horizontalCenter: parent.horizontalCenter
            text: "Svampsnitt"
            font.pixelSize: Math.min(page.width * 0.14, units.gu(9))
            font.weight: Font.Bold
            color: "#FFFFFF"
            style: Text.Outline; styleColor: "#3A2A10"
        }
        Label {
            anchors.horizontalCenter: parent.horizontalCenter
            width: Math.min(implicitWidth, page.width - units.gu(4))
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            text: root.tr("Slice the mushrooms – but never the fly agaric")
            color: "#FFFFFF"
            style: Text.Outline; styleColor: "#3A2A10"
        }
    }

    // De tre lägena som svampar i ringar
    readonly property real targetSize: Math.min(units.gu(12), (width - units.gu(8)) / 3)
    Row {
        id: targets
        anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: parent.height * 0.38 }
        spacing: units.gu(2)
        ModeTarget {
            id: classicT
            width: page.targetSize
            kind: "chanterelle"
            title: root.modeName("classic")
            subtitle: root.best("classic") > 0 ? root.tr("Best: %1").arg(root.best("classic")) : ""
            onChosen: root.play("classic")
        }
        ModeTarget {
            id: timedT
            y: units.gu(5)
            width: page.targetSize
            kind: "porcini"
            title: root.modeName("timed")
            subtitle: root.best("timed") > 0 ? root.tr("Best: %1").arg(root.best("timed")) : ""
            onChosen: root.play("timed")
        }
        ModeTarget {
            id: zenT
            width: page.targetSize
            kind: "birch"
            title: root.modeName("zen")
            subtitle: root.best("zen") > 0 ? root.tr("Best: %1").arg(root.best("zen")) : ""
            onChosen: root.play("zen")
        }
    }
    readonly property var allTargets: [classicT, timedT, zenT]

    Label {
        anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: parent.height * 0.08 }
        width: Math.min(implicitWidth, page.width - units.gu(4))
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.WordWrap
        text: root.tr("Slice a mushroom to start")
        font.weight: Font.Bold
        color: "#FFFFFF"
        style: Text.Outline; styleColor: "#3A2A10"
        SequentialAnimation on opacity {
            loops: Animation.Infinite
            running: Qt.application.state === Qt.ApplicationActive
            NumberAnimation { from: 1; to: 0.45; duration: 1100; easing.type: Easing.InOutSine }
            NumberAnimation { from: 0.45; to: 1; duration: 1100; easing.type: Easing.InOutSine }
        }
    }

    onVisibleChanged: if (visible) for (var i = 0; i < allTargets.length; i++) allTargets[i].reset()

    // Svep genom en svamp, eller tryck på den
    function hit(ax, ay, bx, by) {
        for (var i = 0; i < allTargets.length; i++) {
            var t = allTargets[i]
            var c = t.mapToItem(page, t.center.x, t.center.y)
            if (Logic.segDist(ax, ay, bx, by, c.x, c.y) <= t.ringSize * 0.45) {
                t.split(Math.atan2(by - ay, bx - ax) * 180 / Math.PI)
                root.playSound("slice")
                return true
            }
        }
        return false
    }

    Trail {
        id: trail
        anchors.fill: parent
        thickness: units.gu(1.8)
        glowColor: root.isDark ? "#B3E5FC" : "#FFF4C2"
    }

    MouseArea {
        anchors.fill: parent
        property real lx: 0
        property real ly: 0
        property real sx: 0
        property real sy: 0
        property double lt: 0
        property bool done: false
        onPressed: { lx = sx = mouse.x; ly = sy = mouse.y; lt = Date.now(); done = false; trail.begin(mouse.x, mouse.y) }
        onPositionChanged: {
            var now = Date.now()
            var dx = mouse.x - lx, dy = mouse.y - ly
            var speed = Math.sqrt(dx * dx + dy * dy) / Math.max(0.001, (now - lt) / 1000)
            if (!done && speed > units.gu(25)) done = page.hit(lx, ly, mouse.x, mouse.y)
            trail.add(mouse.x, mouse.y)
            lx = mouse.x; ly = mouse.y; lt = now
        }
        onReleased: {
            // Ett tryck: ett kort snitt genom punkten
            var moved = Math.abs(mouse.x - sx) + Math.abs(mouse.y - sy)
            if (!done && moved < units.gu(2)) page.hit(mouse.x - 1, mouse.y, mouse.x + 1, mouse.y)
        }
    }

    Row {
        anchors { right: parent.right; top: parent.top; margins: units.gu(1.5) }
        spacing: units.gu(1)
        RoundButton { iconName: "view-list-symbolic"; onClicked: stack.push(Qt.resolvedUrl("RecordsPage.qml")) }
        RoundButton { iconName: "settings"; onClicked: stack.push(Qt.resolvedUrl("SettingsPage.qml")) }
    }
}
