# Changelog

- 1.0.0 – First version: three modes (Classic, Against the clock, Zen), five mushrooms and the fly agaric, combos, three seasons, light and dark theme, English and Swedish.
